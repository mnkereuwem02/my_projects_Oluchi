
Module 2 Assignment (Salary Function)

Description of the task
The goal of this task is to carry out several operations related to data processing, error handling, and file management using Python and R. The program includes creating a Python function that takes an employee’s name as input and returns their details, as well as using R to unzip the generated folder and display the data.

Contents of the ZIP Folder
1. salary_data.ipynb   → Jupyter notebook
2. unzip_file.R    → R script
3. README.txt → This readme file

Requirements(Tools used)
- Python Tool
- pandas library
- utils library
- R Tool

Usage Instructions

Python
------------------
1. Open the folder with the dataset in your python environment.
2. Run the Jupyter Notebook to import salary data and use the provided function.
3. Call `export_employee_to_csv('Employee Name')`- include the employee's name to export employee details.

R
-----------------
1. Open the directory with zipped folder in your R environment
2. Run the provided R script to unzip the folder and display employee data.

