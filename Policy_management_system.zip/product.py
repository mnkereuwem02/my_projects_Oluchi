class Product:
    def __init__(self, product_id, name, price):
        self.product_id = product_id
        self.name = name
        self.price = price
        self.active = True

    def update_product(self, name=None, price=None):
        if name:
            self.name = name
        if price:
            self.price = price

    def suspend_product(self):
        self.active = False
