Policy Management System - Milestone Assignment 1

This system is designed for an insurance company to manage policyholders, insurance products, and payment operations efficiently. It supports key functionalities such as:
* Registering, suspending, and reactivating policyholders.
* Creating, updating, and suspending insurance products.
* Processing payments, applying penalties, and sending payment reminders.
* Displaying detailed account information for each policyholder, including assigned products and payment history.

Project Structure
policy_management_system
├── main.ipynb        # Demonstrates usage of the system  
├── policyholder.py   # Defines the Policyholder class  
├── product.py        # Defines the Product class  
├── payment.py        # Defines the Payment class  
└── Readme.txt        # Overview and usage instructions 


How to Run

1. Ensure Python is installed on your system.
2. Clone or download the project to your local machine.
3. Open a terminal and navigate to the project directory: cd path/to/policy_management_system
4. Launch the main.ipynb notebook to explore system functionality.

File Demonstration (main.ipynb)

This notebook walks through the system's capabilities by:

* Creating a sample insurance product.
* Registering five policyholders.
* Assigning the product to each policyholder.
* Processing payments for all registered policyholders.
* Displaying complete account details, including assigned products and payment history.