# Uncomment the following lines if these packages are not already installed
# install.packages("keras")
# install.packages("reshape2")
# install.packages("ggplot2")

library(keras)
library(reshape2)
library(ggplot2)

# Uncomment the following line if TensorFlow/Keras isn't installed yet
# install_keras()

# Load the Fashion MNIST dataset
fashion_mnist <- dataset_fashion_mnist()
train_images <- fashion_mnist$train$x / 255
train_labels <- fashion_mnist$train$y
test_images <- fashion_mnist$test$x / 255
test_labels <- fashion_mnist$test$y

# Reshape the data to add the channel dimension
train_images <- array_reshape(train_images, c(nrow(train_images), 28, 28, 1))
test_images <- array_reshape(test_images, c(nrow(test_images), 28, 28, 1))

# Building the CNN model
model <- keras_model_sequential() %>%
  layer_conv_2d(filters = 32, kernel_size = c(3, 3), activation = "relu", 
                input_shape = c(28, 28, 1)) %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_conv_2d(filters = 64, kernel_size = c(3, 3), activation = "relu") %>%
  layer_max_pooling_2d(pool_size = c(2, 2)) %>%
  layer_conv_2d(filters = 128, kernel_size = c(3, 3), activation = "relu") %>%
  layer_flatten() %>%
  layer_dense(units = 128, activation = "relu") %>%
  layer_dense(units = 10, activation = "softmax")

# Compile the model
model %>% compile(
  optimizer = "adam",
  loss = "sparse_categorical_crossentropy",
  metrics = "accuracy"
)

# Train the model
model %>% fit(
  train_images, train_labels,
  epochs = 5,
  validation_data = list(test_images, test_labels)
)

# Make predictions on the first two test images (note the extra dimension)
predictions <- model %>% predict(test_images[1:2,,,])
predicted_labels <- apply(predictions, 1, which.max) - 1  # Convert probability outputs to class labels

print(predicted_labels)

# Modified function to display an image with ggplot2
plot_image <- function(image_matrix, label) {
  # Convert the matrix to a data frame for ggplot
  image_df <- as.data.frame(image_matrix)
  image_df$row <- seq_len(nrow(image_df))
  image_df <- melt(image_df, id.vars = "row")
  
  ggplot(image_df, aes(x = as.numeric(variable), y = row, fill = value)) +
    geom_tile() +
    scale_fill_gradient(low = "black", high = "white") +
    scale_y_reverse() +    # Reverse y-axis for correct orientation
    coord_fixed() +        # Maintain a 1:1 aspect ratio
    ggtitle(paste("Predicted Label:", label)) +
    theme_void()
}

# Display the first test image using ggplot2
plot_image(test_images[1,,,1], predicted_labels[1])

# Alternatively, display the first test image using base R graphics
image(1:28, 1:28, t(apply(test_images[1,,,1], 2, rev)),
      col = gray((0:255) / 255),
      main = paste("Predicted Label:", predicted_labels[1]),
      xlab = "", ylab = "",
      asp = 1,                # Force fixed aspect ratio
      ylim = c(28, 1))   # Reverse y-axis to correct the orientation
image(1:28, 1:28, t(apply(test_images[1,,,1], 2, rev)), col = gray((0:255) / 255), main = paste("Predicted Label:", predicted_labels[1]), xlab = "", ylab = "", asp = 1)

# Display the second test image using ggplot2
plot_image(test_images[2,,,1], predicted_labels[2])


