Netflix Data Visualization
Module 4 Assignment

Project Overview
This project analyzes Netflix movies and shows using both Python and R, 
focusing on data cleaning, exploration, visualization, and insights generation.

The main objectives of this project are to:

- Clean and preprocess Netflix data.
- Explore the dataset to understand missing values and feature distributions.
- Visualize insights such as the 'most watched genres' and 'ratings distribution'.
- Use Python libraries ('pandas', 'seaborn', 'matplotlib') for preprocessing and visualizations.
- Integrate an R-based visualization using 'ggplot2'.

The dataset ('Netflix_shows_movies.csv') contains information on Netflix content, including the following columns:

-'show_id'
-'type'
-'title'
-'director'
-'cast'
-'country'
-'date_added'
-'release_year'
-'rating
-'duration'
-'listed_in'
-'description'

Requirements

Python Libraries

-'pandas'
-'seaborn'
-'matplotlib'
-'zipfile'
-'os'

R Libraries

-'ggplot2'
-'dplyr'


Python Version

How to Run:

1. Open the project folder in your Python environment.
2. Open 'Netflix_Data_Visualization.ipynb' in Jupyter Notebook.
3. Run the notebook to:

   - Clean and preprocess the dataset.
   -Display charts for 'most watched genres' and 'ratings distribution'.

R Version

How to Run:

1. Open R or RStudio.
2. Load the script:'Netflix_data_visualization.r'.
3. Use the cleaned dataset ('df_cleaned') exported from the Python notebook.
4. Run the script to generate the most watched genre' visualization.





