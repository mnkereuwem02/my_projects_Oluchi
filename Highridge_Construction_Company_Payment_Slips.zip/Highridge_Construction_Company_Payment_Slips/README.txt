Highridge Construction Company Assignment - Worker Payment Slips
Module 1 Assignment - BAN 6420

Date:05/9/2025 

Contents of the ZIP Folder
1. get_payment_slips.py   → Python script
2. get_payment_slips.R    → R script
3. readme.txt        	 → This readme file

Description
This program automates the generation of weekly payment slips for 400 employees at Highridge Construction Company. 
Its main features include:
- Randomly generating profiles for 400 employees.
- Assigning a gender and salary to each employee.
- Determining each employee's level based on salary and gender using the following conditions:
   - "A1" if the salary is between $10,000 and $20,000.
   - "A5-F" if the salary is between $7,500 and $30,000 and the worker is Female.

Output

The program produces two key outputs:
- A list of employees with valid employee levels ("A1" and "A5-F").
- A list of employees who are not assigned a valid level.

Error Handling

The program is designed to handle errors gracefully
- In Python: using try/except
- In R: using tryCatch()
If any employee profile contains missing or corrupted data, the error is logged, and the program continues processing the remaining workers without interruption.


How to Run the Code
--- Python Version ---
Requirements: Python
Steps:
1. Open a terminal or command prompt.
2. Navigate to the folder with the script.
3. Run the script:
   python get_payment_slips.py

--- R Version ---
Requirements: R (or RStudio)
Steps:
1. Open R or RStudio.
2. Open the script file get_payment_slips.R.
3. Run the script.

 Error Handling
Both the Python and R scripts use exception handling:
- Python: try/except
- R: tryCatch()
If any employee has missing data, the script will log the error  but continue processing the remaining employees.


