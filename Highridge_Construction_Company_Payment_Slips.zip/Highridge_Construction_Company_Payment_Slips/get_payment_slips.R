# Set seed for reproducibility
set.seed(123)

# Generate a list of 400 workers randomly
employees <- list()
genders <- c('Male', 'Female')

# Generate 400 workers with random details
for (i in 1:400) {
  employee <- list(
    id = i,
    name = paste("Employee", i, sep = "_"),
    gender = sample(genders, 1),
    salary = round(runif(1, 5000, 30000), 2)
  )
  employees[[i]] <- employee
}

# Generate payment slips
for (employee in employees) {
  tryCatch({
    undefined_level <- "No level assigned"  # Default value
    
    salary <- employee$salary
    gender <- employee$gender
    
    if (salary > 10000 && salary < 20000) {
      undefined_level <- "A1"
    }
    if (salary > 7500 && salary < 30000 && gender == "Female") {
      undefined_level <- "A5-F"
    }
    
    cat(paste("Payment Slip for", employee$name, "\n"))
    cat(paste("ID:", employee$id, "\nEmployee Level:", undefined_level, "\nGender:", gender, "\nSalary: $", salary, "\n", sep = " "))
    cat(rep("-", 25), "\n")
    
  }, error = function(e) {
    cat(paste("Error for worker ID:", employee$id, "- ", e$message, "\n"))
  })
}

