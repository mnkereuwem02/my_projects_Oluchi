import random

# Generate a list of 400 workers randomly
employees = []
gender = ['Male', 'Female']

try:
    for i in range(400):
        employee = {
            "id": i + 1,
            "name": f"Employee_{i + 1}",
            "gender": random.choice(gender),
            "salary": round(random.uniform(5000, 30000), 2)
        }
        employees.append(employee)

    # Generate payment slips
    for employee in employees:
        try:
            undefined_level="level not assigned"
            salary = employee["salary"]
            gender = employee["gender"]

            if 10000 < salary < 20000:
                undefined_level = "A1"
            if 7500 < salary < 30000 and gender == "Female":
                undefined_level = "A5-F"

            print(f"Payment Slip for {employee['name']} ")
            print(f"ID: {employee['id']}\nEmployee Level: {undefined_level}\nGender: {gender}\nSalary: ${salary}")
            print("=" * 25)

        except KeyError as e:
            print(f"Missing data for worker: {employee.get('id', 'Unknown')}, Error: {e}")

except Exception as e:
    print(f"An unexpected error occurred: {e}")
